package net.lrsoft.mets.renderer.particle;

public interface IXCustomizedEffect {
	void onRender(float partialTicks);
	boolean  getIsFinish();
}
