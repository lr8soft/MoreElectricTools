package net.lrsoft.mets.block.tileentity.GESU;

public class TileEntityGESULuVOutputPort extends TileEntityGESUOutputPort {
	public TileEntityGESULuVOutputPort()
	{
		super(6);
	}
}
