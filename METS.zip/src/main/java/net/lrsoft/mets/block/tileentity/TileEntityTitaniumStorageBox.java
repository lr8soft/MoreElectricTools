package net.lrsoft.mets.block.tileentity;

import ic2.core.block.storage.box.TileEntityStorageBox;

public class TileEntityTitaniumStorageBox extends TileEntityStorageBox {
	public TileEntityTitaniumStorageBox()
	{
		super(84);
	}
}
