package net.lrsoft.mets.block.tileentity;

import ic2.core.block.wiring.TileEntityTransformer;

public class TileEntityTransformerIV extends TileEntityTransformer {

	public TileEntityTransformerIV() {
		super(5);
	}

}
