package net.lrsoft.mets.block.tileentity;

public interface IMets {}
