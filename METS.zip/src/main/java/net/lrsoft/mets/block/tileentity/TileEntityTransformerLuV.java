package net.lrsoft.mets.block.tileentity;

import ic2.core.block.wiring.TileEntityTransformer;

public class TileEntityTransformerLuV extends TileEntityTransformer {

	public TileEntityTransformerLuV() {
		super(6);
	}

}
