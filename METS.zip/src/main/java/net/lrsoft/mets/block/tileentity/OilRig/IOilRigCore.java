package net.lrsoft.mets.block.tileentity.OilRig;

import net.minecraft.util.math.Vec3d;

public interface IOilRigCore {
	Vec3d getRigCoordinate();
	int getCoreState();
}
