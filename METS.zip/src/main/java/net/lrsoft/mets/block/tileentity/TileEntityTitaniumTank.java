package net.lrsoft.mets.block.tileentity;

import ic2.core.block.machine.tileentity.TileEntityTank;

public class TileEntityTitaniumTank extends TileEntityTank 
{
	public TileEntityTitaniumTank() {
		//super(128);
	}
}
